import React from "react";
import download from "../images/cat-6593947_960_720.jpg";

const Header = () => {
  return (
    <div>
      <img
        src={download}
       
      />
    </div>
  );
};

export default Header;
